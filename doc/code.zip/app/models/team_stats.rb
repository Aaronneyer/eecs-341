class TeamStats < ActiveRecord::Base
end
