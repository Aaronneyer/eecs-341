class PlayerStats < ActiveRecord::Base
end
