class SearchController < ApplicationController
end
