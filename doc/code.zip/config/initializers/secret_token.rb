# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Eecs341::Application.config.secret_key_base = '978f5004e88eacebf2ea67620aa22b5d47435e11b017cf735424b468262fceb313ad47321b15b1635797955157c0a4feaf93d986eb11716efcda76d38732b7ab'
