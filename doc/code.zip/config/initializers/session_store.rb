# Be sure to restart your server when you modify this file.

Eecs341::Application.config.session_store :cookie_store, key: '_eecs-341_session'
