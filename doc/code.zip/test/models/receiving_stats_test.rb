require 'test_helper'

class ReceivingStatsTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
