require 'test_helper'

class StatsTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
