require 'test_helper'

class RushingStatsTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
