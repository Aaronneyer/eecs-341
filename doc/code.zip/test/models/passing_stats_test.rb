require 'test_helper'

class PassingStatsTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
