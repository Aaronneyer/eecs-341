require 'test_helper'

class TeamsYearsTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
