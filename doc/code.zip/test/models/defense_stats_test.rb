require 'test_helper'

class DefenseStatsTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
