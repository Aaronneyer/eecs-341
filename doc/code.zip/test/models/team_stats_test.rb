require 'test_helper'

class TeamStatsTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
