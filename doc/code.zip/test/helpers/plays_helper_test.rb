require 'test_helper'

class PlaysHelperTest < ActionView::TestCase
end
