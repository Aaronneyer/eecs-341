require 'test_helper'

class TeamsHelperTest < ActionView::TestCase
end
